@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="outerBox">
                <div class="title m-b-md" style="font-family: 'Modak', cursive; font-size:130px;
">
                    <div class="boxed" style=" border: 35px solid grey;">
                        Can you hear

                        Blackboard?
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection